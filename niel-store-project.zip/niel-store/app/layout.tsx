import "./globals.css";
import { Toaster } from "react-hot-toast";
export const metadata={title:"NIEL STORE",description:"Marketplace akun game dan layanan sosmed."};
export default function RootLayout({children}:{children:React.ReactNode}){
  return <html lang="id"><body><Toaster position="top-right"/>{children}</body></html>;
}