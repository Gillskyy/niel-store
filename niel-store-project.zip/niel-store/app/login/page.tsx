 "use client";
import {useState} from "react";
import {useRouter} from "next/navigation";
import {supabase} from "@/lib/supabase";
import toast from "react-hot-toast";
export default function Login(){
 const [email,setEmail]=useState(""); const [password,setPassword]=useState(""); const [loading,setLoading]=useState(false); const router=useRouter();
 async function submit(e:React.FormEvent){e.preventDefault();setLoading(true);try{
  const {data,error}=await supabase.auth.signInWithPassword({email,password}); if(error)throw error;
  const {data:p}=await supabase.from("profiles").select("role").eq("id",data.user.id).single();
  if(!p||p.role!=="admin"){await supabase.auth.signOut();throw new Error("akun ini bukan admin");}
  router.push("/admin");
 }catch(e:any){toast.error(e.message||"gagal login")}finally{setLoading(false)}}
 return <main className="flex min-h-screen items-center justify-center p-4"><form onSubmit={submit} className="card w-full max-w-md p-7"><h1 className="text-2xl font-black">NIEL STORE</h1><p className="mb-6 mt-1 text-sm text-slate-500">admin control panel</p><input className="input mb-3" type="email" placeholder="email admin" value={email} onChange={e=>setEmail(e.target.value)} required/><input className="input mb-4" type="password" placeholder="password" value={password} onChange={e=>setPassword(e.target.value)} required/><button className="btn w-full" disabled={loading}>{loading?"memproses...":"masuk dashboard"}</button></form></main>
}