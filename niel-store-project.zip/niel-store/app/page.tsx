 "use client";
import {useEffect,useState} from "react";
import Link from "next/link";
import {supabase} from "@/lib/supabase";

const wa="6283121711321";
export default function Home(){
 const [accounts,setAccounts]=useState<any[]>([]);
 const [services,setServices]=useState<any[]>([]);
 const [tests,setTests]=useState<any[]>([]);
 const [settings,setSettings]=useState<any>({store_name:"NIEL STORE",description:"Pusat jual beli akun game dan layanan sosmed.",whatsapp_number:wa});
 useEffect(()=>{load()},[]);
 async function load(){
  const [a,s,t,set]=await Promise.all([
   supabase.from("accounts").select("*").eq("status","available").order("created_at",{ascending:false}),
   supabase.from("services").select("*").order("created_at",{ascending:false}),
   supabase.from("testimonials").select("*").order("created_at",{ascending:false}),
   supabase.from("settings").select("*").eq("id",1).maybeSingle()
  ]);
  if(a.data)setAccounts(a.data); if(s.data)setServices(s.data); if(t.data)setTests(t.data); if(set.data)setSettings(set.data);
 }
 const buy=(text:string)=>window.open(`https://wa.me/${settings.whatsapp_number}?text=${encodeURIComponent(text)}`,"_blank");
 return <main>
  <header className="sticky top-0 z-20 border-b border-white/10 bg-[#08080c]/90 backdrop-blur">
   <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-4">
    <b className="text-xl">NIEL <span className="text-blue-400">STORE</span></b>
    <Link className="text-sm text-slate-400 hover:text-white" href="/login">admin login</Link>
   </div>
  </header>
  <section className="mx-auto max-w-6xl px-4 py-16 text-center">
   <p className="mb-3 text-sm font-bold text-blue-400">DIGITAL GAMING MARKETPLACE</p>
   <h1 className="text-5xl font-black md:text-7xl">NIEL STORE</h1>
   <p className="mx-auto mt-4 max-w-2xl text-slate-400">{settings.description}</p>
   <div className="mt-8 flex justify-center gap-3"><a className="btn" href="#akun">lihat akun</a><a className="rounded-xl border border-white/10 px-5 py-3 font-bold" href="#sosmed">layanan sosmed</a></div>
  </section>
  <section id="akun" className="mx-auto max-w-6xl px-4 py-10">
   <h2 className="mb-5 text-2xl font-black">akun game</h2>
   <div className="grid gap-5 md:grid-cols-3">{accounts.length?accounts.map(a=><article className="card overflow-hidden" key={a.id}>
    {a.image_url&&<img src={a.image_url} alt="" className="h-48 w-full object-cover"/>}
    <div className="p-5"><p className="text-xs text-blue-400">{a.game}</p><h3 className="mt-1 text-lg font-bold">{a.title}</h3><p className="mt-2 text-slate-400">{a.description}</p><p className="mt-4 text-xl font-black">Rp {Number(a.price).toLocaleString("id-ID")}</p><button className="btn mt-4 w-full" onClick={()=>buy(`halo niel store, saya mau membeli akun ${a.title} (${a.game})`)}>beli via whatsapp</button></div>
   </article>):<p className="text-slate-500">belum ada akun tersedia.</p>}</div>
  </section>
  <section id="sosmed" className="mx-auto max-w-6xl px-4 py-10">
   <h2 className="mb-5 text-2xl font-black">suntik sosmed</h2>
   <div className="grid gap-5 md:grid-cols-3">{services.length?services.map(s=><article className="card p-5" key={s.id}><p className="text-xs text-purple-400">{s.category}</p><h3 className="mt-1 font-bold">{s.title}</h3><p className="mt-2 text-sm text-slate-400">{s.description}</p><p className="mt-4 text-xl font-black">Rp {Number(s.price).toLocaleString("id-ID")}</p><button className="btn mt-4 w-full" onClick={()=>buy(`halo niel store, saya mau order ${s.title}`)}>order via whatsapp</button></article>):<p className="text-slate-500">belum ada layanan.</p>}</div>
  </section>
  <section className="mx-auto max-w-6xl px-4 py-10"><h2 className="mb-5 text-2xl font-black">testimoni</h2><div className="grid gap-4 md:grid-cols-3">{tests.map(t=><article className="card p-5" key={t.id}><div className="text-yellow-400">{"★".repeat(Math.max(1,Math.min(5,t.rating||5)))}</div><p className="mt-3 text-slate-300">"{t.comment}"</p><p className="mt-4 font-bold">{t.client_name}</p><p className="text-xs text-slate-500">{t.game_or_service}</p></article>)}</div></section>
  <footer className="border-t border-white/10 py-8 text-center text-xs text-slate-500">© {new Date().getFullYear()} NIEL STORE</footer>
 </main>
}