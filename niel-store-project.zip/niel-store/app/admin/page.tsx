 "use client";
import {useEffect,useState} from "react";
import Link from "next/link";
import {useRouter} from "next/navigation";
import {supabase} from "@/lib/supabase";
export default function Admin(){
 const [ok,setOk]=useState(false); const [stats,setStats]=useState({a:0,s:0,t:0,f:0}); const router=useRouter();
 useEffect(()=>{(async()=>{const {data:{session}}=await supabase.auth.getSession();if(!session){router.push("/login");return}const {data:p}=await supabase.from("profiles").select("role").eq("id",session.user.id).single();if(!p||p.role!=="admin"){await supabase.auth.signOut();router.push("/login");return}
  const [a,s,t,f]=await Promise.all([supabase.from("accounts").select("*",{count:"exact",head:true}),supabase.from("services").select("*",{count:"exact",head:true}),supabase.from("testimonials").select("*",{count:"exact",head:true}),supabase.from("feedbacks").select("*",{count:"exact",head:true})]);setStats({a:a.count||0,s:s.count||0,t:t.count||0,f:f.count||0});setOk(true)})()},[router]);
 async function logout(){await supabase.auth.signOut();router.push("/login")}
 if(!ok)return <div className="p-8 text-slate-400">memuat dashboard...</div>;
 return <main className="mx-auto max-w-6xl p-5"><div className="flex items-center justify-between"><div><p className="text-sm text-blue-400">ADMIN PANEL</p><h1 className="text-3xl font-black">niel store</h1></div><button onClick={logout} className="rounded-xl border border-white/10 px-4 py-2 text-sm">logout</button></div>
 <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{[["akun",stats.a],["sosmed",stats.s],["testimoni",stats.t],["feedback",stats.f]].map(x=><div className="card p-5" key={x[0]}><p className="text-sm text-slate-500">{x[0]}</p><b className="text-3xl">{x[1]}</b></div>)}</div>
 <div className="mt-8 grid gap-4 md:grid-cols-2"><Link href="/admin/accounts" className="card p-6 font-bold hover:border-blue-500/50">kelola akun game →</Link><Link href="/admin/services" className="card p-6 font-bold hover:border-blue-500/50">kelola sosmed →</Link></div>
 </main>
}